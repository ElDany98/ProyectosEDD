/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.poo;
import java.util.Scanner;


/**
 *
 * @author Sala
 */
public class ProyectoPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //declaracion de variables
        int opciones;
        
        
        //fin de las variables
        //declaracion de objetos
        refescos ref = new refescos();
        //fin declaracion de objetos
        Scanner leer = new Scanner(System.in);
        System.out.println("***Menu***");
        System.out.println("1.- consultar productos");
        System.out.println("2.- vender productos");
        System.out.println("3.- Eliminar producto");
        opciones=leer.nextInt();
        switch(opciones)
        {//switch de acciones
            case 1:
                System.out.println("********************");
                System.out.println("Que producto deseas consultar");
                System.out.println("1.- refescos");
                System.out.println("2.- papas");
                System.out.println("3.- chocolates");
                System.out.println("4.- limpieza");
                System.out.println("5.- salchichoneria");
                System.out.println("6.- refrigerados");
                System.out.println("7.- panaderia");
                System.out.println("8.- servicios");
                System.out.println("9.- dulceria");
                System.out.println("");
                opciones=leer.nextInt();
                switch(opciones)
                {//switch de productos
                    case 1:
                        System.out.println("**************************************");
                        System.out.println("1.-Coca Cola Familiar");
                        System.out.println("2.-Squirt");
                        System.out.println("3.-Mirinda");
                        System.out.println("4.-Sprite");
                        System.out.println("5.-Manzanita");
                        System.out.println("6.-Fresca");
                        System.out.println("7.-Fanta");
                        System.out.println("8.-Jarrito");
                        opciones=leer.nextInt();
                        switch(opciones)
                        {//switch refrescos
                            case 1:
                                ref.cocacolafam();
                                break;
                            case 2:
                                ref.squirt();
                                break;
                        }//switch refrescos
                        
                break;        
                }//switch de productos
             break;   
                
            
        }//switch de acciones
        
        
    }
    
}
