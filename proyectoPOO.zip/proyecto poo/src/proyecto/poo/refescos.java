/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.poo;

/**
 *
 * @author Sala
 */
public class refescos {
    int existencia = 100;
    String nombre,unidades;
    double precio,contenido;
    
    
    
    public void cocacolafam()
    {
        nombre="Coca Cola ";
        unidades=" lt";
        precio=35.0;
        existencia=100;
        System.out.println("Nombre del producto "+ nombre);
        System.out.println("Precio "+ precio);
        System.out.println("Existencia "+existencia);
        
    }

    public refescos() {
    }
    
    public void squirt()
    {
        nombre="Squirt ";
        unidades=" lt";
        precio=12.0;
        existencia=100;
        System.out.println("Nombre del producto "+ nombre);
        System.out.println("Precio "+ precio);
        System.out.println("Existencia "+existencia);
    }
    
}
