/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author danie
 */
public class test
{
    public static void arreglo()
    {
        String vec[]={"3","no"};
        String res[]=new String[vec.length];
        System.arraycopy(vec, 0, res, 0, vec.length);
        
        for (int i = 0; i < vec.length; i++)
        {
            System.out.println(res[i]);
        }
        
    }
    
}
