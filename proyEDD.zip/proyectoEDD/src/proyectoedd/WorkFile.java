/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoedd;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Sala
 */
public class WorkFile {
    
    private String ruta;
    private String file;

    public WorkFile( String file) {
        this.ruta = "C:\\Users\\danie\\Documents\\NetBeansProjects\\proyectoEDD\\";//esta es la ruta 
        this.file = file;
    }

    public void escribir(String text) 
    {
        try
        {
        FileWriter Wrote = new FileWriter(this.ruta+this.file,true);// este es la clase o libreria que lee el archivo
        Wrote.write(text);
        Wrote.write("\n");
        Wrote.close();
        }
        catch(IOException e )
        {
            System.out.println("Exception "+e.toString());
        }
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }
    
    
    public void leer()
    {
        try
        {
        FileReader ler = new FileReader(this.ruta+this.file);//esta es la libreria que lee el archivo o si no existe lo crea
        int c=ler.read();
        while(c!=-1)
        {
            main mn = new main();
            
            //System.out.print((char)c);
            
            c=ler.read();
        }
            System.out.println("");
            ler.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Exception "+e.toString());
        }
        catch(IOException e)
        {
         System.out.println("Exception "+e.toString());   
        }
    }
    
    
    
}
